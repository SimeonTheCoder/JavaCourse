package app.controllers;

import app.Data;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HPCntrl {
    public static int sumRes = 0;

    @GetMapping("/")
    ModelAndView loadHome(ModelAndView modelAndView){
        modelAndView.setViewName("index.html");
        modelAndView.addObject("sum", sumRes);
        return modelAndView;
    }

    @PostMapping("/sum")
    String sum(Data data){
        int a = data.getA();
        int b = data.getB();

        int r = sumMethod(a, b);
        sumRes = r;

        return "redirect:/";
    }

    private int sumMethod(int a, int b) {
        int res = 0; //Enter expression here

        return res;
    }
}
