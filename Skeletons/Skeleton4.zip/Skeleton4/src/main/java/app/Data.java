package app;

public class Data {
    public String fNum;
    public String sNum;

    public Data(String fNum, String sNum) {
        this.fNum = fNum;
        this.sNum = sNum;
    }

    public String getfNum() {
        return fNum;
    }

    public void setfNum(String fNum) {
        this.fNum = fNum;
    }

    public String getsNum() {
        return sNum;
    }

    public void setsNum(String sNum) {
        this.sNum = sNum;
    }
}
