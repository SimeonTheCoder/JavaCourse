package app;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Cntrl {
    String f = "0", s = "0";
    String r = "0";
    char sign = '+';

    @GetMapping("/")
    ModelAndView showndex(ModelAndView modelAndView) {
        modelAndView.setViewName("index.html");
        System.out.println(r);
        modelAndView.addObject("r", r);
        return modelAndView;
    }

    @PostMapping("/p")
    String setPlus(){
        sign = '+';
        return "redirect:/";
    }

    @PostMapping("/s")
    String setMinus(){
        sign = '-';
        return "redirect:/";
    }

    @PostMapping("/m")
    String setMul(){
        sign = '*';
        return "redirect:/";
    }

    @PostMapping("/d")
    String setDiv(){
        sign = '/';
        return "redirect:/";
    }

    @PostMapping("/c")
    String calculate(Data data){
//        System.out.println(data.fNum + " " + data.sNum);
        f = data.fNum;
        s = data.sNum;

        int a = Integer.parseInt(f);
        int b = Integer.parseInt(s);

        switch (sign) {
            case '+' :
                r = String.valueOf(plus(a, b));

                break;

            case '-' :
                r = String.valueOf(minus(a, b));

                break;

            case '*' :
                r = String.valueOf(mul(a, b));

                break;

            case '/' :
                r = String.valueOf(div(a, b));

                break;
        }

        return "redirect:/";
    }
}
